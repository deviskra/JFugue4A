/**
 * The J2ME adaptation of JFugue (http://www.jfugue.org)
 *@author Mitya Klochan (d.klochan@gmail.com)
 *@version 1.0
 */

package j2me.midi;

import android.media.MediaPlayer;

//import java.io.InputStream;
//import java.io.ByteArrayInputStream;

import java.io.IOException;
import android.media.MediaCasException;
import android.media.MediaDataSource;
import java.nio.file.*;
import java.io.*;
import android.media.*;
import android.util.*;
import java.net.*; 

/**
 * Class partly implements java Sequencer interface for J2ME
 * 
 * @version 1.0
 */
public class Sequencer {
    
    protected MediaPlayer player = new MediaPlayer();
     
    public Sequencer() {
        
    }
    
    
    /**
     * Sets the current sequence on which the sequencer operates.
     *
     */
    
    public void setSequence (Sequence sequence) throws IOException {
		String uri = "data:audio;base64,";
		uri+= Base64.encodeToString(sequence.toByteArray(),Base64.DEFAULT);
        player.reset();
		player.setDataSource(uri);
		player.prepare();
    };
    
    /**
     * Starts playback of the MIDI data in the currently
     * loaded sequence.
     * Playback will begin from the current position.
     * If the playback position reaches the loop end point,
     * and the loop count is greater than 0, playback will
     * resume at the loop start point for the number of
     * repetitions set with <code>setLoopCount</code>.
     * After that, or if the loop count is 0, playback will
     * continue to play to the end of the sequence.
     *
     * @see #setLoopCount
     * @see #stop
     */
    public void start() {
            player.start();       
    }
    
    /**
     * Closes the device, indicating that the device should now release
     * any system resources it is using.
     *
     * @see #open
     */
    public void close() {
       player.release();
    }
    
    /**
     * Stops playback of the currently loaded sequence,
     * if any.
     *
     * @see #start
     * @see #isRunning
     */
    public void stop(){
                  player.stop();
     }
    
    /**
     * Sets the number of repetitions of the loop for
     * playback.
     * When the playback position reaches the loop end point,
     * it will loop back to the loop start point
     * <code>count</code> times, after which playback will
     * continue to play to the end of the sequence.
     * <p>
     * If the current position when this method is invoked
     * is greater than the loop end point, playback
     * continues to the end of the sequence without looping,
     * unless the loop end point is changed subsequently.
     * <p>
     * A <code>count</code> value of 0 disables looping:
     * playback will continue at the loop end point, and it
     * will not loop back to the loop start point.
     * This is a sequencer's default.
     *
     * <p>If playback is stopped during looping, the
     * current loop status is cleared; subsequent start
     * requests are not affected by an interrupted loop
     * operation.
     *
     * @param count the number of times playback should
     *        loop back from the loop's end position
     *        to the loop's start position, or -1
     *        to indicate that looping should
     *        continue until interrupted
     *
     *
     * @see #getLoopCount
     * @see #start
     * @since 1.5
     */
    public void setLoopCount(int count) {
        player.setLooping((count > 0) ? true:false);
    };
        
    /**
     * Indicates whether the Sequencer is currently running.  The default is <code>false</code>.
     * The Sequencer starts running when either <code>{@link #start}</code> or <code>{@link #startRecording}</code>
     * is called.  <code>isRunning</code> then returns <code>true</code> until playback of the
     * sequence completes or <code>{@link #stop}</code> is called.
     * @return <code>true</code> if the Sequencer is running, otherwise <code>false</code>
     */
    public boolean isRunning() {
        return player.isPlaying();
	}
    
    /**
     * Obtains the length of the current sequence, expressed in microseconds,
     * or 0 if no sequence is set.
     * @return length of the sequence in microseconds.
     */
    public long getMicrosecondLength() {
        return player.getDuration();
    };
    
    /**
     * Obtains the current position in the sequence, expressed in
     * microseconds.
     * @return the current position in microseconds
     * @see #setMicrosecondPosition
     */
    public long getMicrosecondPosition() {
        return player.getCurrentPosition();
    };
    
     /**
     * Sets the current position in the sequence, expressed in microseconds
     * @param microseconds desired position in microseconds
     * @see #getMicrosecondPosition
     */
    public void setMicrosecondPosition(int microseconds) {
                  player.seekTo(microseconds);
       
    };
    
}
