package jfugue4a.test;

import android.app.*;
import android.os.*;
import org.jfugue.*;
import android.view.*;
import android.widget.*;
import android.util.*;
import org.xmlpull.v1.*;
import org.json.*;

public class MainActivity extends Activity 
{
	Player player = new Player();
    
	@Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
    }
	
	public void Play(View v){
		EditText jfTextField = findViewById(R.id.jfugueTextField);
		String str = jfTextField.getText().toString();
		player.play(str);
		
		
		
		
		//JSONObject jobj = new JSONObject("\{ "user":"ku"\}[);
		
	}
}
