/**
 * The J2ME adaptation of JFugue (http://www.jfugue.org)
 *@author Mitya Klochan (d.klochan@gmail.com)
 *@version 1.0
 */

package org.jfugue;


import j2me.midi.Sequencer;
import j2me.midi.Sequence;
import java.io.IOException;
import android.media.*;

/**
 * Prepares a pattern to be turned into music by the Renderer.  This class
 * also handles saving the sequence derived from a pattern as a MIDI file.
 *
 *@see MidiRenderer
 *@see Pattern
 *@author David Koelle
 *@version 2.0
 */
public class Player extends Sequencer implements PatternListener
{
    /**
     * Instantiates a new Player object, which is used for playing music.
     */
    public Player()
    {
   
    }

    /**
     * Plays a pattern by setting up a Renderer and feeding the pattern to it.
     * @param pattern the pattern to play
     * @see MidiRenderer
     */
    public void play(Pattern pattern)
    {
        Sequence sequence = getSequence(pattern);
        play(sequence);
    }
    
    
    /**
     * Plays a MIDI Sequence
     * @param sequence the Sequence to play
     * @throws JFugueException if there is a problem playing the music
     * @see MidiRenderer
     */
    public void play(Sequence sequence)
    {
        
        // Play the sequence
        try {
             setSequence(sequence);
        } catch (Exception e)
        {
            throw new JFugueException(JFugueException.ERROR_PLAYING_MUSIC);
        }

        start();
             
    }

    /**
     * Plays a string of music.  Be sure to call player.close() after play() has returned.
     * @param musicString the MusicString (JFugue-formatted string) to play
     * @version 3.0
     */
    public void play(String musicString) 
    {
        if (musicString.indexOf(".mid") > 0)
        {
            throw new JFugueException(JFugueException.PLAYS_STRING_NOT_FILE_EXC);
        }
        
        play(new Pattern(musicString));
    }
    
   
    /**
     * Returns the sequence containing the MIDI data from the given pattern.
     * @return the Sequence from the given pattern
     */
    
    public Sequence getSequence(Pattern pattern)
    {
        MidiRenderer renderer = new MidiRenderer();
        Sequence sequence = renderer.render(pattern);
        return sequence;
    }
    
    /**
     * Sets the current sequence from given JFugue pattern.
     *
     * @param pattern JFugue pattern.
     */
    public void setSequence(Pattern pattern)
    {
        MidiRenderer renderer = new MidiRenderer();
        
        try {
            setSequence(renderer.render(pattern));
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        
    }
   
    
     /**
     * Returns underlying Media Player Instance.
     * just for a case you need access to native controls
     * 
     */
    public android.media.MediaPlayer getMediaPlayerInstance(){
          return player;
    }
    
    
    /**
     * Prevents music from playing for one whole rest.
     * @version 3.0
     */
    public void rest()
    {
        play("Rw");
    }
    
    /**
     * Sets up a Pattern to be played as new parts are added to it.
     * @param pattern The Pattern to which new fragments will be added
     */
    public void startStream(Pattern pattern)
    {
        pattern.addPatternListener(this);
    }
    
    /**
     * Stops streaming a Pattern
     * @param pattern The Pattern to which new fragments were added
     */
    public void stopStream(Pattern pattern)
    {
        pattern.removePatternListener(this);
    }
    
    //
    // Pattern Listener
    //

    /**
     * Listener for additions to streaming patterns.  When a fragment has been
     * added to a pattern, this implementation plays the pattern.
     * @param fragment the fragment added to the pattern.
     */
    public void fragmentAdded(Pattern fragment)
    {
        play(fragment);
    }
}


