package org.jfugue;

import j2me.util.EventListener;

public interface ParserProgressListener extends EventListener
{
    public void progressReported(String description, long partCompleted, long wholeSize);
}
